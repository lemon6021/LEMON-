import discord, asyncio
from discord.ext import commands


ecolor = 0x00ff56
errorcolor = 0xff0000

class Core(commands.Cog):

    def __init__(self, bot): 
        self.bot = bot

    @commands.command(name="핑")
    async def ping(self, ctx):
        pings = round(self.bot.latency*1000)
        if pings < 100:
            pinglevel = '🔵 매우좋음'
            color=ecolor
        elif pings < 300: 
            pinglevel = '🟢 양호함'
            color=ecolor
        elif pings < 400: 
            pinglevel = '🟡 보통'
            color=ecolor
        elif pings < 6000: 
            pinglevel = '🔴 나쁨'
            color=errorcolor
        else: 
            pinglevel = '⚪ 매우나쁨'
            color=errorcolor
        e = discord.Embed(title=':ping_pong: 퐁!', description=f'{pings} ms\n{pinglevel}', color=color)
        await ctx.send(embed=e)

    @commands.command(name="dm", aliases = ['DM'])
    async def DM(self, ctx, member:discord.Member=None, *, text = None):
        if member == None:
            await ctx.send(f'유저를 멘션해주세요! (예시:.DM {self.bot.user.mention} 내용)')
            return
        if text == None:
            await ctx.send("보낼 내용을 입력해주세요")
            return
        await self.bot.get_user(member.id).send(f'{text}\n`{ctx.author.name}님의 요청에 의해 전송 되었어요.[저작권](https://github.com/happy-jin1234/INFINITYBOT)`')
        await ctx.send(f'{member.name}님에게 메시지가 전송 되었습니다.')

def setup(bot):
    bot.add_cog(Core(bot))
