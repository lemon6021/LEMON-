#모듈
import discord,asyncio,os,random,aiosqlite,json
from discord.ext import commands
from discord.ext import tasks
from requests import post
from discord.utils import get
from urllib.request import urlopen
from bs4 import BeautifulSoup
from urllib import parse
from json import loads
from discord_buttons_plugin import *
from discord_components import DiscordComponents, Button, ButtonStyle, interaction, Select

#모듈 끝
#기타

def checkowner(ctx):
    return ctx.author.id == 795662249557622804 or ctx.author.id == 654245768055619584 or ctx.author.id == 791881249102364692

intents = discord.Intents.all()
#접두사&버튼
bot = commands.Bot(command_prefix='S', intents=intents)
buttons = ButtonsClient(bot)

#접두사&버튼 끝
#토큰

token = "OTA3OTgxMzY5NTQyNTk0Njcx.YYvFiw.DKzC-w-gmaxVX51ovHkrC47UqnQ"
#토큰 끝
embedcolor = 0x00ff56
embederrorcolor = 0xff0000

for filename in os.listdir("Cogs"):
    if filename.endswith(".py"):
        bot.load_extension(f"Cogs.{filename[:-3]}")

#봇 이밴트 시작

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.CommandOnCooldown):
        return await ctx.send(
            f"레몬봇도 힘들어요ㅠㅠ {round(ctx.command.get_cooldown_retry_after(ctx))}초 후에 다시 시도 해주세요!"
        )
    embed = discord.Embed(title="오류가 발생했습니다!", description=f"```{error}```")
    await ctx.send(embed=embed)

#봇 이벤트 끝

#봇 커맨드 시작

@bot.command("봇정보")
async def botinfo(ctx):
    embed = discord.Embed(title="레몬봇 서포터의 정보",
                          description="V 1.0.0",
                          color=0x00ff00)
    embed.add_field(name="레몬봇 서포터 개발 언어", value="파이썬(python)", inline=False)
    embed.add_field(name="호스팅", value="Linux server", inline=False)
    embed.add_field(name="개발시작일", value="2021/11/7", inline=False)
    embed.add_field(name="소속 팀", value="무 소속", inline=False)
    embed.add_field(name="지원 서버 링크",
                    value="[서포트 서버](https://discord.gg/u5tvjuaZCF)",
                    inline=False)
    embed.add_field(name="개발자", value="레몬#2021")
    await ctx.send(embed=embed)

#서버 관리 기능 시작

@bot.command(name="슬로우모드")
@commands.has_permissions(manage_channels=True)
async def slowmode(ctx, time: int = None):
    if time == None:
        await ctx.send("\❌ 슬로우모드를 몇초로 설정할지 보내주세요.")
        return
    elif time == 0:
        await ctx.send("\✅슬로우모드를 껐어요.")
        await ctx.channel.edit(slowmode_delay=0)
        return
    elif time > 21600:
        await ctx.send("\❌ 슬로우모드를 6시간 이상 설정할수 없어요.")
        return
    else:
        await ctx.channel.edit(slowmode_delay=time)
        await ctx.send(f"\✅ 성공적으로 슬로우모드를 {time}초로 설정했어요.")

@bot.command(name="broadcastmsg", aliases=["채널메세지"])
@commands.check(checkowner)
async def broadcast(ctx):
    try:
        await ctx.message.delete()
    except:
        pass
    channel = int(ctx.message.content[7:25])
    msg = ctx.message.content[26:]
    await bot.get_channel(channel).send(msg)

@bot.command(name="채팅청소")
async def chatclear(ctx, num: int):
    if ctx.author.guild_permissions.manage_messages:
        await ctx.channel.purge(limit=num)
        await ctx.send(f"**{num}**개의 메시지를 지웠습니다.")
    else:
        await ctx.send("당신에게 삭제 권한이 없습니다.")

@bot.command(name="추방", aliases=['킥'])
async def kickuser(ctx, member: discord.Member):
    if ctx.author.guild_permissions.kick_members:
        try:
            await ctx.guild.kick(member)
        except:
            await ctx.send("사용자를 추방하지 못했어요...")
        else:
            await ctx.send(
                random.choice([
                    "후훗 보내 버렸어요.", "사용자를 킥했어요.", "킥을 하니 시원하네요.",
                    "이제 사용자는 서버에서 강제로 추방되었어요."
                ]))

@bot.command(name="밴", aliases=['차단'])
async def cmd_ban(ctx, user: discord.Member):
    if ctx.author.guild_permissions.ban_members:
        try:
            await ctx.guild.ban(user)
        except:
            await ctx.send("사용자를 밴하지 못했어요...")
        else:
            msg = random.choice([
                "후훗 보내 버렸어요.", "사용자를 밴했어요.", "밴을 하니 시원하네요.",
                "이제 사용자는 서버에 들어올 수 없어요."
            ])
            await ctx.send(msg)
    else:
        await ctx.send("권한이 부족해요!")

#서버 관리 기능 끝

#기타 기능

@bot.command(name="공지")
@commands.check(checkowner)
async def dev_broadcast(ctx, *, msg):
    noreceive = ["111111111111111111111111"]
    for guild in bot.guilds:
        if str(guild.id) in noreceive:
            pass
        else:
            embed1 = discord.Embed(
                title="레몬봇 서버 공지",
                description=f"{msg}\n\n----------------------",
                color=discord.Color.orange())
            embed1.set_footer(text=f'Sent By {ctx.author}')

            for channel in guild.text_channels:
                try:
                    if channel.topic.find("-레몬봇서포터") != -1:
                        chan = channel
                except:
                    pass
            try:
                chan
                if chan.permissions_for(guild.me).send_messages:
                    await chan.send(embed=embed1)
                    print(f"공지 전송: {guild.name}, 공지 채널 있음.")
                    del chan
            except:
                for channel in guild.text_channels:
                    if channel.permissions_for(guild.me).send_messages:
                        embed1.set_footer(
                            text=
                            f'By {ctx.author}'
                        )
                        try:
                            await channel.send(embed=embed1)
                        except:
                            pass
                        print(f"공지 전송: {guild.name}, 공지 채널 없음.")
                        break
    await ctx.send("공지 업로드 완료!")

@bot.command()
async def 규칙(ctx):
    await ctx.send("레몬 서포터 서버의 규칙입니다.", components=[
                Button(label='''규칙''', style=ButtonStyle.URL, url='https://discord.com/channels/906517533304172604/906800897215037530/906879470688927834',)
                ])

@bot.command()
async def 이용약관(ctx):
    await ctx.send("아래 원하는 버튼을 눌러주세요.", components=[
                Button(label='''이용약관''', style=ButtonStyle.URL, url='https://lemonbot.xyz/이용약관',),
                Button(label='''개인정보처리방침''', style=ButtonStyle.URL, url='https://lemonbot.xyz/개인정보처리방침',)
                ])

#기타 기능 끝

#경제 기능 시작

@bot.command(name="경고부여")
@commands.check(checkowner)
async def dev_editmoney(ctx, _user: discord.Member, _money: int):
    if _money < 0:
        if not await removemoney(_user.id, (_money + _money * -2)):
            return await ctx.send("그 사용자의 경고을 마이너스로 부여할수없어요!")
        await ctx.send(f"경고 {_money}개을 {_user.mention} 에게 취소하였습니다.")
    else:
        await addmoney(_user.id, _money)
        await ctx.send(f"경고 {_money}개을 {_user.mention} 에게 부여하였습니다.")

@bot.command(name="경고")
async def moneyy(ctx, _user: discord.Member = None):
    if _user is None:
        _user = ctx.author
    aiocursor = await aiodb.execute("select * from money where id=?",
                                    (_user.id, ))
    dat = await aiocursor.fetchall()
    if str(dat) == '[]':
        _m = 0
    else:
        _m = dat[0][1]
    await ctx.send(
        embed=discord.Embed(title=f"{_user.name}님의 경고수", description=f"{_m}"))

async def addmoney(_id, _amount):
    aiocursor = await aiodb.execute("select * from money where id=?", (_id, ))
    dat = await aiocursor.fetchall()
    await aiocursor.close()
    if str(dat) == '[]':
        aiocursor = await aiodb.execute(
            "insert into money (id, money) values (?, ?)", (_id, _amount))
        await aiodb.commit()
        await aiocursor.close()
    else:
        aiocursor = await aiodb.execute(
            "update money set money = ? where id = ?",
            (dat[0][1] + _amount, _id))
        await aiodb.commit()
        await aiocursor.close()

async def getmoney(_id):
    aiocursor = await aiodb.execute("select * from money where id=?", (_id, ))
    dat = await aiocursor.fetchall()
    await aiocursor.close()
    if str(dat) == '[]':
        return 0
    return dat[0][1]

async def removemoney(_id, _amount):
    aiocursor = await aiodb.execute("select * from money where id=?", (_id, ))
    dat = await aiocursor.fetchall()
    await aiocursor.close()
    if str(dat) == '[]':
        return False
    if dat[0][1] < _amount:
        return False
    aiocursor = await aiodb.execute("update money set money = ? where id = ?",
                                    (dat[0][1] - _amount, _id))
    await aiodb.commit()
    await aiocursor.close()
    return True

@bot.command(name="가입")
async def cmd_register(ctx: discord.ext.commands.Context):
    aiocursor = await aiodb.execute("select * from user where id=?",
                                    (ctx.author.id, ))
    dbdata = await aiocursor.fetchall()
    await aiocursor.close()
    if str(dbdata) == '[]':
        insertdb = True
    else:
        insertdb = False
    if insertdb:
        aiocursor = await aiodb.execute(
            "insert into user (id, tos) values (?, ?)",
            (ctx.author.id, "True"))
        await aiodb.commit()
        await aiocursor.close()
        await ctx.send(embed=discord.Embed(
            title="가입 완료",
            description=f"{ctx.author.mention}\n가입이 완료됐습니다. 이제 봇을 사용하실 수 있습니다."
        ))
        return
    else:
        aiocursor = await aiodb.execute("UPDATE user SET tos = ? WHERE id=?",
                                        ("True", ctx.author.id))
        await aiodb.commit()
        await aiocursor.close()
        await ctx.send(embed=discord.Embed(
            title="❌ 오류", description=f"{ctx.author.mention}\n가입이 되있는 유저 입니다.")
                       )
        return

#경제 기능 끝

#봇 커맨드 끝

@bot.event
async def on_ready():
    print(f'Main\n{bot.user.name}')


@tasks.loop(seconds=3)
async def change_status():
    status = [f'레몬봇 서포터', '관리']
    for i in status:
        await asyncio.sleep(3)
        await bot.change_presence(status=discord.Status.online,
                                  activity=discord.Game(i))


change_status.start()
aiodb = None


async def startup():
    global aiodb
    if aiodb is None:
        aiodb = await aiosqlite.connect("database.db")
    DiscordComponents(bot)
    await bot.start(token, reconnect=True)


async def shutdown():
    await aiodb.close()


try:
    (asyncio.get_event_loop()).run_until_complete(startup())
except KeyboardInterrupt:
    (asyncio.get_event_loop()).run_until_complete(shutdown())
